# To-Do List Application - TASK 1

The **To-Do List Application** enables users to manage and organize their tasks effectively. Made in command-line interface (CLI) , Here's how  this application works  :

1. **Create Tasks:**
   - Users can add new tasks to their to-do list.
   - For example, you might input: "Buy groceries," "Finish report," or "Call Mom."

2. **Update Tasks:**
   - Mark tasks as completed or update their status.
   - You can set priorities, due dates, or additional notes for each task.

3. **Track Progress:**
   - The application displays the list of tasks, making it easy to see what needs to be done.
   - Completed tasks can be checked off, and pending tasks remain visible.

4. **Stay Organized:**
   - Use the To-Do List Application to stay on top of your responsibilities.
   - Never forget an important task again!

